<html>
    <head>
</head>
<body>
<form actions = "fileupload.php " methods = "POST" enctype="multipart/form-data">
  
    <input type = "file" name="audioFile">
    <input type="submit"   value = "upload audio"  name = "save_audio">
  
</form>     
</body>
</html>