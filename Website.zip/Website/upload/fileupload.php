<?php
echo "Prasad";
if(isset($_POST['save_audio']) && $_POST['save_audio']=="Upload Audio"){
    $dir = 'songshere/';
    $audio_path = $dir.basename($_FILES['audioFile']['name']);

    if(move_uploaded_file($_FILES['audioFile']['tmp_name'],$audio_path))
    {
            echo 'uploaded successfully';
            saveAudio($audio_path);
    }
} 

function saveAudio($fileName){
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "prasadvvv";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
else{
     echo "connected";
}


    $query = "insert into audio(filename) values('{$filename}')";

    mysqli_query($conn,$query);
    if(mysqli_affected_rows($conn)>0)
    {
        echo "audio path saved in database";
    }
    mysqli_close($conn);
}
echo "vaskar"; 

?>