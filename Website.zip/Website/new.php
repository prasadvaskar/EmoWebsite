<!DOCTYPE>
<html>
<head>
</head>
<body>
//Surabh Naare
<p>Prasad</p>
//asfdaef

<form actions="upload.php" method="POST" enctype="multipart/form-data">
<input type= "file" name="audioFile"/>
<input type= "submit" value="Upload Audio" name="save_audio"/>
</form>
</body>
</html>